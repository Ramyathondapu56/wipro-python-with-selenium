import requests

try:
    response = requests.get("https://api.restful-api.dev/objects")
    print(response)

    if response.status_code == 200:
        print("Status code is 200 ok")

        data = response.json()
        print(data)

    else:
        raise Exception(f"Request failed with status code {response.status_code}")

except Exception as e:
    print(f"An error occured: {e}")