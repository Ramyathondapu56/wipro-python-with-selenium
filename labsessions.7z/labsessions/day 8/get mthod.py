import requests

try:
    response = requests.get("https://jsonplaceholder.typicode.com/users")
    print(response)

    if response.status_code == 200:
        print("Status code is 200 ok")

        data = response.json()

        for user in data:
            print("Name:", user["name"])
            print("Email:", user["email"])
            print("-----")

    else:
        print(f"Error:Received status code{response.status_code}")

except requests.exceptions.RequestException as e:
    print(f"An error occured: {e}")