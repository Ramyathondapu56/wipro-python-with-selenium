import requests
from bs4 import BeautifulSoup

html = """
<html>
<head><title>Test Page</title></head>
<body>
<h1>Welcome</h1>
<p>This is a paragraph.</p>
<a href="https://example.com">Click Here</a>
<div class="product">
    <h2>iPhone 15</h2>
    <span class="price">₹80,000</span>
    <span class="rating">4.5</span>
    <span class="availability">In Stock</span>
</div>
</body>
</html>
"""

soup = BeautifulSoup(html, "html.parser")

# Extract title
print("Title:", soup.title.text)

# Extract h1
print("H1:", soup.h1.text)

# Extract paragraph
print("Paragraph:", soup.p.text)

link = soup.find("a")

if link:
    print("First link:", link)
    print("Href:", link.get("href"))

    print(soup.prettify())
    soup.find("p")  # First paragraph only
    soup.find_all("p")  # All paragraphs (list)


#2nd question
product = soup.find("div", class_="product")

name = product.find("h2").text
price = product.find("span", class_="price").text
rating = product.find("span", class_="rating").text
availability = product.find("span", class_="availability").text

print(name, price, rating, availability)
images = soup.find_all("img")

for img in images:
    print(img.get("src"))


base_url = "https://books.toscrape.com/"
response = requests.get(base_url)
soup = BeautifulSoup(response.text, "html.parser")

books = soup.find_all("article", class_="product_pod")

for book in books:
    name = book.h3.a["title"]
    price = book.find("p", class_="price_color").text
    rating = book.find("p", class_="star-rating")["class"][1]

    product_link = base_url + book.h3.a["href"]
    product_response = requests.get(product_link)
    product_soup = BeautifulSoup(product_response.text, "html.parser")

    availability = product_soup.find("p", class_="instock availability").text.strip()

    print("Product Name:", name)
    print("Price:", price)
    print("Rating:", rating)
    print("Availability:", availability)
    print("-" * 40)

print("All Image URLs:\n")

images = soup.find_all("img")
for img in images:
    image_url = base_url + img.get("src").replace("../", "")
    print(image_url)



