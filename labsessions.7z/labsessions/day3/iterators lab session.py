class CountFive:
    def __init__(self):
        self.num = 1

    def __iter__(self):
        return self   # returns the iterator object itself

    def __next__(self):
        if self.num <= 5:
            val = self.num
            self.num += 1
            return val
        else:
            raise StopIteration   # signals end of iteration

# Usage
for i in CountFive():
    print(i)


#2 question
class EvenIterator:
    def __init__(self):
        self.num = 0

    def __iter__(self):
        return self

    def __next__(self):
        self.num += 2
        return self.num
evens = EvenIterator()
for _ in range(5):
    print(next(evens))


#3 question
# -------------------------------
# Custom Iterator Example
# -------------------------------
class CountFive:
    def __init__(self):
        self.num = 1   # starting point

    def __iter__(self):
        return self    # returns the iterator object

    def __next__(self):
        if self.num <= 5:
            val = self.num
            self.num += 1
            return val
        else:
            raise StopIteration   # signals end of iteration


