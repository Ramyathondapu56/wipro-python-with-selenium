#2 practice question
def get_integer_input(prompt):
    while True:
        user_input = input(prompt)
        try:
            # Try converting input to integer
            value = int(user_input)
            return value
        except ValueError:
            # Handle invalid input
            print("Invalid input! Please enter a valid integer.")
age = get_integer_input("Enter your age: ")
print(age)


#3
import random
import string
# random alphabet character
random_char = random.choice(string.ascii_letters)
print("Random Alphabet Character:", random_char)
# random alphabet string (random length)
length = random.randint(5, 10)   # random length between 5 and 10
random_string = ''.join(random.choice(string.ascii_letters) for _ in range(length))
print("Random Alphabet String:", random_string)
# random alphabet string of fixed length
fixed_length = 8
fixed_string = ''.join(random.choice(string.ascii_letters) for _ in range(fixed_length))
print("Fixed Length String:", fixed_string)


#1
try:
    with open("C://Users//HP//PycharmProjects//PythonProject//Python advance programing//selenium with python//LabSessions//file formates//nestjson.json", "r") as file :
        data = json.load(file)
        print(data)
except FileNotFoundError:
    (print("File not found, Error Exception when opening a File"))