# 1 question generator to generate numbers from 1 to N
def numbers_upto_n(n):
    for i in range(1, n+1):
        yield i
for num in numbers_upto_n(5):
    print(num)

#2 question Even numbers generation only
def even_numbers(n):
    for i in range(2, n+1, 2):
        yield i
for num in even_numbers(10):
    print(num)


#3 question
def read_file(filename):
    with open(filename,"r") as f:
        for line in f:
            yield line

for line in read_file("C://Users//ramya//PycharmProjects//PythonProject6python with selenium//labsessions//day3//iterators lab session.py"):
    print(line.strip())


#4 question fibonacci series
def fibonacci(n):
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b
for num in fibonacci(10):
    print(num)


#5 question retry maxim of three attempts
def retry(max_attempts=3):
    for attempt in range(1, max_attempts+1):
        yield f"Attempt {attempt}"

for attempt in retry():
    print(attempt)

#second method
def retry():
    for attempt in range(1, 4):
        yield attempt


correct_password = "1234"

for attempt in retry():
    pwd = input(f"Attempt {attempt}: Enter password: ")

    if pwd == correct_password:
        print("Login Successful")
        break
else:
    print("Maximum attempts reached. Try again later.")