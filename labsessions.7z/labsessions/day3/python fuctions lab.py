def sum_list(numbers):
    total = 0
    for num in numbers:
        total += num
    return total
print(sum_list([1, 2, 3, 4, 5]))
#method 2
def sum_list(nums):
    return sum(nums)
print(sum_list([1,2,3,4,5]))


#2nd question
def find_max(a, b, c):
    if a >= b and a >= c:
        return a
    elif b >= a and b >= c:
        return b
    else:
        return c
print(find_max(9, 6, 5))


# 2 method
def max_find(a,b,c):
    return max(a,b,c)
print(find_max(1,4,6))
