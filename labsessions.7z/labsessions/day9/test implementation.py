#1 question
import pytest
#testcase 1
def testcase1():
    print("Testcase1 is executed")
#testcase2
@pytest.mark.skip(reason="Feature not implemented yet")
def test_new_feature():
    assert False
def testcase2():
    print("Testcase2 is executed")
#testcase3
def testcase3():
    print("Testcase3 is executed")
#testcase4
@pytest.mark.skip
def openbrowser():
    print("Opening the browser")


#2 question

import sys

@pytest.mark.skipif(sys.platform.startswith("win"), reason="Runs only on Linux")
def test_linux_only():
    assert True


#3 question
import requests

def test_api_health():
    try:
        response = requests.get("https://example.com/health", timeout=5)
    except requests.exceptions.RequestException:
        pytest.skip("API not reachable")

    if response.status_code != 200:
        pytest.skip(f"API returned {response.status_code}")

    assert response.status_code == 200


#4th question

@pytest.mark.xfail(reason="Bug #123")
def test_known_bug():
    assert 1 == 2


#5th question


def double_number(num):
    # Intentional bug: wrong logic for 3 and 4
    if num == 3:
        return 5   # should be 6
    if num == 4:
        return 7   # should be 8
    return num * 2


@pytest.mark.parametrize(
    "num, expected",
    [
        (1, 2),   # normal case
        (2, 4),   # normal case

        pytest.param(
            3, 6,
            marks=pytest.mark.xfail(reason="Bug #101 - incorrect logic for 3")
        ),

        pytest.param(
            4, 8,
            marks=pytest.mark.xfail(reason="Bug #102 - incorrect logic for 4")
        ),

        (5, 10),  # normal case
    ]
)
def test_double_number(num, expected):
    assert double_number(num) == expected