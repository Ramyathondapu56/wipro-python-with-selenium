# Program to find the largest number in a list

def find_largest(numbers):
    if not numbers:
        return None

    largest = numbers[0]
    for num in numbers:
        if num > largest:
            largest = num
    return largest

# Example usage
my_list = [12, 45, 67, 23, 89, 34]
print("The largest number is:", find_largest(my_list))


# Program to remove even numbers from a list

def remove_even(numbers):
    result = []
    for num in numbers:
        if num % 2 != 0:
            result.append(num)
    return result

# Example usage
my_list = [12, 45, 67, 23, 89, 34]
print("List after removing even numbers:", remove_even(my_list))


# Program to multiply all items in a list

def multiply_list(numbers):
    result = 1
    for num in numbers:
        result *= num
    return result

my_list = [12, 45, 67, 23, 89, 34]
print("The product of all numbers is:", multiply_list(my_list))