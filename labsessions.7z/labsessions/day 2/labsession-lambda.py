nums = [1, 2, 3, 4, 5, 6]
evens = list(filter(lambda x: x % 2 == 0, nums))
print(evens)

nums = [1, 2, 3, 4, 5, 6]
evens = list(map(lambda x: x % 2 == 0, nums))
print(evens)

nums = [1, 2, 3, 4, 5, 6]
squares = list(map(lambda x: x ** 2,nums))
print(squares)

nums = [1, 2, 3, 4, 5, 6]
squares = list(filter(lambda x: x * x,nums))
print(squares)



#2 question

salaries = [25000, 40000, 32000, 18000]
good_salaries = list(filter(lambda sal: sal > 30000, salaries))
print("salaries above 30,000 are:")
print(good_salaries)
hiked_salaries = list(map(lambda s: s + (s * 0.1), good_salaries))
print("salaries after hike:")
print(hiked_salaries)
total_payout = reduce(lambda x, y: x + y, hiked_salaries)
print("total payout:")
print(total_payout)

# 2nd question diff pettern
from functools import reduce

salaries = [25000, 40000, 32000, 18000]

# Filter salaries > 30,000
filtered_salaries = list(filter(lambda x: x > 30000, salaries))

# Add 10% hike
hiked_salaries = list(map(lambda x: x * 1.10, filtered_salaries))

# Find total payout
total_payout = reduce(lambda x, y: x + y, hiked_salaries)
print(total_payout)  # Output: 79200.0