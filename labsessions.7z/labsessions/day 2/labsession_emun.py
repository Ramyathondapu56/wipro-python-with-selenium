#1
print(list(enumerate(['a','b','c'])))

#2
for i, v in enumerate([10,20,30]):
    print(i,v)

#3
colors = ['red', 'green', ' blue']
for i, v in enumerate(colors, start=1):
    print(i,v)

#4
word = "python"
for i, ch in enumerate(word, start=1):
    print(i,ch)

#5
nums = [10,20,30,40,50,60]
for i, v in enumerate(nums):
    if v == 50:
        print(f"index: {i}")

#6
for i, n in enumerate(range(10, 60, 10)):
    print(i, n)

#7
data=['red', 'green', 'blue']
for i in range(len(data)):
    print(i, data[i])


#8
items = ['a', 'b', 'c']
for i in enumerate(items):
    print(i)

#9
print(list(enumerate([], start=5)))

#10
for i, v in enumerate([100, 200, 300], start=-1):
    print(i, v)

#11
for i, v in enumerate(['x', 'y', 'z']):
    print(i,v)
#12
data=('a','b','c')
print(list(enumerate(data)))
print(list(enumerate(data, start =1)))

