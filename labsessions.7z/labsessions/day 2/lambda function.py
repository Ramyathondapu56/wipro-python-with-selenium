# Python program to sort a list of tuples using lambda

# Sample list of tuples
data = [(2, 'banana'), (1, 'apple'), (4, 'mango'), (3, 'cherry')]

# Sort by the first element of each tuple
sorted_by_first = sorted(data, key=lambda x: x[0])
print("Sorted by first element:", sorted_by_first)

# Sort by the second element of each tuple
sorted_by_second = sorted(data, key=lambda x: x[1])
print("Sorted by second element:", sorted_by_second)



#2
# Python program to extract year, month, date and time using lambda

import datetime

# Current datetime
now = datetime.datetime.now()

# Lambda functions to extract components
extract_year  = lambda dt: dt.year
extract_month = lambda dt: dt.month
extract_day   = lambda dt: dt.day
extract_time  = lambda dt: dt.strftime("%H:%M:%S")

# Display results
print("Current Date and Time:", now)
print("Year:", extract_year(now))
print("Month:", extract_month(now))
print("Day:", extract_day(now))
print("Time:", extract_time(now))

#3
# Python script to concatenate dictionaries

# Sample dictionaries
dict1 = {1: "apple", 2: "banana"}
dict2 = {3: "cherry", 4: "date"}
dict3 = {5: "mango", 6: "grape"}

# Method 1: Using update()
new_dict = {}
for d in (dict1, dict2, dict3):
    new_dict.update(d)

print("Concatenated dictionary (using update):", new_dict)

# Method 2: Using dictionary unpacking (Python 3.5+)
new_dict_unpack = {**dict1, **dict2, **dict3}
print("Concatenated dictionary (using unpacking):", new_dict_unpack)