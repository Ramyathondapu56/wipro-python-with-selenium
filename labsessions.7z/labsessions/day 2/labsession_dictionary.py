#  dictionary with roll number as key and name as value
students = {
    101: "Alice",
    102: "Bob",
    103: "Charlie"
}

# Print the dictionary
print("Dictionary:", students)

# Access the value of a key that exists
print("Value for key 102:", students[102])

# Access the value of a key that does not exist
print(students.get(105, "Key not found"))

# Update the value of an existing key
students[103] = "David"
print("Updated Dictionary:", students)

# Delete a key using del
del students[101]
print(students)

# Delete a key using pop()
removed_value = students.pop(102)
print(students)
print(removed_value)

# Finding the number of key–value pairs
print("Number of key-value pairs:", len(students))

#  keys
print("Keys:", students.keys())

# values
print("Values:", students.values())

# key–value pairs
print("Key-Value pairs:", students.items())