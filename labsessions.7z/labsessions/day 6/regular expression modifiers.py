#1Write a regex to check if a string contains only digits.
import re
text="apple banana carrot"
result= re.findall( r"^\d+$", text)
print(result)

#2Write a pattern to match a 10-digit mobile number
text="9392416394"
result=re.findall(r"^\d{10}$",text)
print(result)

#3Find all lowercase letters in a string.
text="Helloworld123"
result=re.findall( r"[a-z]",text)
print(result)

#4Extract all uppercase letters from a sentence.
text="HelloWorld"
result=re.findall( r"[A-Z]",text)
print(result)

#5Match a string that starts with "Hello".
text="Hello there"
result=re.match(r"^Hello",text)
print(result)


#6Match a string that ends with "world".
text="This is the world"
result=re.findall(r"\bworld\b",text)
print(result)

#7Find all words separated by spaces.
text="Find all words here"
result=re.findall(r"\b\w+\b",text)
print(result)

#8Match exactly 5 characters.
text="abcde"
result=re.match(r"^.{5}$",text)
print(result)

#9Find all occurrences of the word "python" (case-sensitive).
text="python is easy. Python simple"
result=re.findall(r"python",text)
print(result)

#10Replace all spaces in a string with underscores
text ="Ramya hari"
result=re.sub(r'\s+', "_",text)
print(result)

