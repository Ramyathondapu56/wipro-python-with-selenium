class Employee:
    def calculate_salary(self):
        return 50000

class Manager(Employee):
    def calculate_salary(self):
        base_salary = super().calculate_salary()
        bonus = 20000
        return base_salary+bonus

emp = Employee()
mgr = Manager()

ref = emp
print("Employee Salary:", ref.calculate_salary())

ref = mgr
print("Manager Salary:", ref.calculate_salary())




#2 model
class Employee():
    def __init__(self,name,id,salary):
        self.name = name
        self.id = id
        self.salary = salary
    def calculate_salary(self):
        return(self.salary)


class Manager(Employee):
    def calculate_salary(self):
        bonus=5000
        return self.salary + bonus
emp = Employee("Maneesha",4355,40000)
mgr=Manager("Maneesha",4355,40000)

print("Employee salary",emp.calculate_salary())
print("salary with bonus", mgr.calculate_salary())



#2 question

class Animal:

    def speak(self):
        print("Animal makes sound")

class Dog(Animal):
    def speak(self):
        print ("Woof!")

class Cat(Animal):
    def speak(self):
        print("Meow")

class Cow(Animal):
    def speak(self):
        print("Moo")
a=Dog()
a.speak()
b=Cat()
b.speak()
c=Cow()
c.speak()


#2nd model #2nd question
class Dog:

    def speak(self):
        print("ufff")
class cat:

    def speak(self):
        print("meoww")
class cow:

    def speak(self):
        print("bowwww")
def animal_sound(obj):
    obj.speak()

a = Dog()
b=cat()
c=cow()
animal_sound(a)
animal_sound(b)
animal_sound(c)

#3 question
class Vehicle:
    def fuel_type(self):
        print("petrol")


class Car(Vehicle):
    def fuel_type(self):
        print("Diesel")

class ElectricCar(Car):
    def fuel_type(self):
        print("Electric")

v = Vehicle()
c = Car()
e = ElectricCar()

v.fuel_type()
c.fuel_type()
e.fuel_type()


#4 question
class BankAccount:
    def __init__(self, balance):
        self.balance = balance

    def __add__(self, other):
        return BankAccount(self.balance + other.balance)

    def __gt__(self, other):
        return self.balance > other.balance

    def __str__(self):
        return f"Balance: {self.balance}"

# Demonstration
acc1 = BankAccount(5000)
acc2 = BankAccount(3000)

acc3 = acc1 + acc2
print(acc3)

print("acc1 > acc2?", acc1 > acc2)


#6 question
class A:
    def show(self):
        print("A's show")

class B(A):
    def show(self):
        print("B's show")

class C(A):
    def show(self):
        print("C's show")

class D(B, C):
    pass

d = D()
d.show()  # Which one gets called?

print(D.mro())  # Method Resolution Order


#7 question

