#Patient registers (POST)
import requests

BASE_URL = "https://jsonplaceholder.typicode.com/posts"

headers = {
    "Authorization": "Bearer abc123token",
    "Content-Type": "application/json"
}

# -------------------------
# 1) INVALID AGE
# -------------------------
print("\n--- TEST: Invalid Age ---")

payload = {
    "name": "Ramya",
    "age": -5,
    "email": "ramya@gmail.com",
    "phone": "9392461394"
}

if payload["age"] < 0:
    print("PASS: Validation triggered -> 400 Bad Request (Invalid Age)")
else:
    response = requests.post(BASE_URL, json=payload, headers=headers)
    print(response.status_code)


# -------------------------
# 2) MISSING EMAIL
# -------------------------
print("\n--- TEST: Missing Email ---")

payload = {
    "name": "Ramya",
    "age": 23,
    "phone": "9392461394"
}

if "email" not in payload:
    print("PASS: Validation triggered -> 400 Bad Request (Missing Email)")
else:
    response = requests.post(BASE_URL, json=payload, headers=headers)
    print(response.status_code)


# -------------------------
# 3) DUPLICATE PHONE
# -------------------------
print("\n--- TEST: Duplicate Phone ---")

existing_phone = "9392461394"
new_phone = "9392461394"

if new_phone == existing_phone:
    print("PASS: Validation triggered -> 409 Conflict (Duplicate Phone)")
else:
    response = requests.post(BASE_URL, json=payload, headers=headers)
    print(response.status_code)