import requests
headers = {
    "Authorization": "Bearer abc123token",
    "Content-Type": "application/json"
}

try:
    print("\n--- CREATE DOCTOR ---")

    payload = {
        "name": "Dr. Mehta",
        "specialization": "Cardiologist",
        "experience": 12
    }

    response = requests.post("https://jsonplaceholder.typicode.com/posts"
, json=payload, headers=headers)

    print("Status Code:", response.status_code)

    if response.status_code == 201:
        doctor_id = response.json()["id"]
        print("PASS: Doctor created with ID:", doctor_id)

        with open("doctor_id.txt", "w") as f:
            f.write(str(doctor_id))
    else:
        print("FAIL: Doctor not created")

except Exception as e:
    print("Error:", e)