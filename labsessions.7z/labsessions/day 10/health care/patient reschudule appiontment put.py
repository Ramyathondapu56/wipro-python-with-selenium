#Patient reschedules appointment (PUT)
print("\n--- RESCHEDULE APPOINTMENT ---")

# read stored appointment
with open("appointment_id.txt") as f:
    appointment_id = f.read()

# current appointment in DB
appointment_db = {
    "id": appointment_id,
    "date": "2026-03-10",
    "time": "10:00"
}

# user tries new slot
new_date = "2026-03-11"
new_time = "11:00"

# slots already booked in system
booked_slots = [
    ("2026-03-11", "11:00"),
    ("2026-03-12", "12:00")
]

print("Trying to update to:", new_date, new_time)

# conflict validation
if (new_date, new_time) in booked_slots:
    print("Status Code: 409")
    print("PASS: Time slot already booked")

    # verify old appointment unchanged
    if appointment_db["date"] == "2026-03-10" and appointment_db["time"] == "10:00":
        print("PASS: Old appointment remains unchanged")
    else:
        print("FAIL: Appointment modified incorrectly")

else:
    appointment_db["date"] = new_date
    appointment_db["time"] = new_time
    print("Status Code: 200")
    print("PASS: Appointment rescheduled")