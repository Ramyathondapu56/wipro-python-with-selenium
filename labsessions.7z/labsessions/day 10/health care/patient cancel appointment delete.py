#Patient cancels appointment (DELETE)
print("\n--- CANCEL APPOINTMENT ---")

# simulate DB
appointment_db = {
    "9001": {
        "patient_id": 101,
        "doctor_id": 501,
        "date": "2026-03-10",
        "time": "10:00",
        "status": "BOOKED"
    }
}

# read appointment id
import os

if not os.path.exists("appointment_id.txt"):
    print("ERROR: Run book_appointment.py first")
    exit()

with open("appointment_id.txt") as f:
    appointment_id = f.read().strip()

# ---------------- FIRST DELETE ----------------
print("\nFirst Cancel Attempt:")

if appointment_id in appointment_db and appointment_db[appointment_id]["status"] == "BOOKED":
    appointment_db[appointment_id]["status"] = "CANCELLED"
    print("Status Code: 204")
    print("PASS: Appointment cancelled")

else:
    print("Status Code: 404")
    print("FAIL: Appointment not found")


# ---------------- SECOND DELETE ----------------
print("\nSecond Cancel Attempt:")

if appointment_id not in appointment_db:
    print("Status Code: 404")
    print("PASS: Already deleted")

elif appointment_db[appointment_id]["status"] == "CANCELLED":
    print("Status Code: 410")
    print("PASS: Resource Gone (better API design)")
else:
    print("Status Code: 204")