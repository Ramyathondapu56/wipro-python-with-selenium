import requests

BASE_URL = "https://jsonplaceholder.typicode.com/users/1"

try:
    print("\n--- UPDATE CUSTOMER ---")

    payload = {
        "id": 1,
        "name": "Leanne Graham",
        "email": "updatedemail@gmail.com"
    }

    response = requests.put("https://jsonplaceholder.typicode.com/users/1", json=payload)

    print("Status Code:", response.status_code)

    # VALIDATION 1 → STATUS CODE
    if response.status_code == 200:
        print("PASS: Status code = 200")

        data = response.json()

        # VALIDATION 2 → EMAIL UPDATED
        if data["email"] == payload["email"]:
            print("PASS: Email updated")
        else:
            print("FAIL: Email not updated")

        # VALIDATION 3 → ID SAME
        if data["id"] == payload["id"]:
            print("PASS: ID remains same")
        else:
            print("FAIL: ID changed")

    else:
        print("FAIL: Update request failed")

except Exception as e:
    print("Error:", e)