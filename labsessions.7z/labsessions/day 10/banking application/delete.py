import requests

try:
    print("\n--- DELETE CUSTOMER ---")

    response = requests.delete("https://jsonplaceholder.typicode.com/users/1")

    print("Status Code:", response.status_code)

    # VALIDATION 1 → STATUS CODE
    if response.status_code == 200:
        print("PASS: Delete request accepted (mock API)")

    # VALIDATION 2 → VERIFY DELETE
    response = requests.get("https://jsonplaceholder.typicode.com/users/1")

    if response.status_code == 404:
        print("PASS: Record removed")
    else:
        print("NOTE: Mock API keeps data → logically considered deleted")

except Exception as e:
    print("Error:", e)