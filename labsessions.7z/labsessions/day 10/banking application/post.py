import requests

try:
    print("\n--- CREATE CUSTOMER ---")

    payload = {
        "name": "Ramya",
        "email": "ramya@gmail.com"
    }

    response = requests.post("https://jsonplaceholder.typicode.com/users", json=payload)

    print("Status Code:", response.status_code)

    if response.status_code != 201:
        print("FAIL: Expected 201")
        exit()

    data = response.json()

    customer_id = data["id"]
    print("PASS: Customer created with ID:", customer_id)

    with open("customer_id.txt", "w") as f:
        f.write(str(customer_id))

except Exception as e:
    print("Error:", e)