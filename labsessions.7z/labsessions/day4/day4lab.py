import math

class Circle:
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2

    def perimeter(self):
        return 2 * math.pi * self.radius

# Example usage
c = Circle(5)
print("Area:", c.area())
print("Perimeter:", c.perimeter())


#2 question
from datetime import date

class Person:
    def __init__(self, name, country, dob):
        self.name = name
        self.country = country
        self.dob = dob  # dob should be a date object

    def age(self):
        today = date.today()
        age = today.year - self.dob.year
        if (today.month, today.day) < (self.dob.month, self.dob.day):
            age -= 1
        return age

# Example usage
p = Person("Ramya", "India", date(2000, 2, 9))
print("Name:", p.name)
print("Country:", p.country)
print("Age:", p.age())


#3 question
import math

class Shape:
    def area(self):
        raise NotImplementedError("Subclass must implement area method")

    def perimeter(self):
        raise NotImplementedError("Subclass must implement perimeter method")

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2

    def perimeter(self):
        return 2 * math.pi * self.radius

class Square(Shape):
    def __init__(self, side):
        self.side = side

    def area(self):
        return self.side ** 2

    def perimeter(self):
        return 4 * self.side

class Triangle(Shape):
    def __init__(self, a, b, c):
        self.a, self.b, self.c = a, b, c

    def perimeter(self):
        return self.a + self.b + self.c

    def area(self):
        s = self.perimeter() / 2
        return math.sqrt(s * (s - self.a) * (s - self.b) * (s - self.c))

# Example usage
shapes = [Circle(5), Square(4), Triangle(3, 4, 5)]
for s in shapes:
    print(f"{s.__class__.__name__} -> Area: {s.area()}, Perimeter: {s.perimeter()}")



#4 question
class Vehicle:
    def __init__(self, name, max_speed, mileage):
        self.name = name
        self.max_speed = max_speed
        self.mileage = mileage

    def display_info(self):
        return f"{self.name} | Speed: {self.max_speed} | Mileage: {self.mileage}"

class Bus(Vehicle):
    pass  # inherits everything from Vehicle

# Example usage
bus = Bus("School Bus", 80, 12)
print(bus.display_info())