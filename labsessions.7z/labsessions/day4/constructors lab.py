#create a class Book with attributes title and author

class Book:
    def __init__(self, title, author):
        # Constructor initializes attributes
        self.title = title
        self.author = author

    def display(self):
        print(f"Title : {self.title}")
        print(f"Author: {self.author}")
        print("-" * 30)


# Creating three book objects using constructor
book1 = Book("The Alchemist", "Paulo Coelho")
book2 = Book("1984", "George Orwell")
book3 = Book("Python Programming", "John Zelle")

# Displaying details of all books
book1.display()
book2.display()
book3.display()


#1st question method 2
class book():
    def __init__(self,title, author):
        self.title=title
        self.author=author

    def details(self):
        print(self.title, self.author)
auth1=book("Title: Meera talanted girl,","Author: Meearabai")
auth2=book("Title: Gardening Therapy,","Author: Vivek")
auth3=book("Title: Undercoverage ","Author: Deepak")

auth1.details()
auth2.details()
auth3.details()


#create a class Rectangle with a constructor that takes length and width

class Rectangle:
    def __init__(self, length, width):
        # Constructor initializes attributes
        self.length = length
        self.width = width
        self.area = length * width
        self.perimeter = 2 * (length + width)

    def display(self):
        print({self.length})
        print({self.width})
        print({self.area})
        print({self.perimeter})
        print("-" * 30)


#  objects
rect1 = Rectangle(10, 5)
rect2 = Rectangle(7, 3)

# Displaying details
rect1.display()
rect2.display()