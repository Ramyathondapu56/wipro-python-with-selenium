import json

with open("C://Users//ramya//PycharmProjects//PythonProject6python with selenium//dataformats//employee.json", 'r') as file:
     data = json.load(file)

print(data)
print(data["name"])

with open("C://Users//ramya//PycharmProjects//PythonProject6python with selenium//dataformats//nestedjson.json", 'r') as file:
    data = json.load(file)

email = data["user"]["profile"]["email"]

print(email)