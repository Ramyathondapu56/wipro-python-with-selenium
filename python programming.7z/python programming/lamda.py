# lambda functions - anonymous (nameless) functions , one line

# function - function name, arguments, return type, code

# it can have any number of arguments

#must have only one expression

# the expression is automatically returned
#function - function name, arguments, return type,code,

# normal function add 2 numbers

def add(a,b):
    return a+b

print(add(5,3))

# lambda function

add = lambda a,b:a+b
print(add(5,3))

# square of a number
square = lambda x : x*x
print(square(5))

#even or odd
num = lambda a: a%2==0
print(num(6))

# find the max of 2 numbers

mx = lambda a, b: a if a > b else b
print(mx(10, 20))


# filter, map and reduce in built functions in lambda

#filter - select data - filtering the data
# map - transform the data
# reduce - aggregate the data

# filter

numbers = [1,2,3,4,5,6]

evens = list(filter(lambda x:x%2==0,numbers))
print(evens)

# filter the failed testcases

status = ['pass', 'Fail', 'pass', 'Fail']

failed = list(filter(lambda s:s == 'Fail',status))
print((failed))

# filter the positive numbers

nums = [-5, 10, -3, 7, 0, 2]
positive_nums = list(filter(lambda n:n>=0,nums))
print(positive_nums)

# print filter non-empty strings

data = ["hello", "", "world", "", "python"]
non_empty=list(filter(lambda x:x!="",data))
print(non_empty)

# reduce - aggegrate - combining many values to a one single result


from functools import reduce
nums = [10,20,30,40]
print(reduce(lambda x,y : x+y , nums))

nums = [10,20,30,40]
print(reduce(lambda x,y:x*y,nums))

#max
nums = [10,20,30,40]
print(reduce(lambda x, y: max(x,y), nums))

#min
nums = [10,20,30,40]
print(reduce(lambda x,y: min (x,y), nums))

# mapping transform the data - the function is applied to evey element

nums = [10,20,30,40]

squares = list (map(lambda x:x*x, nums))
print(squares)

# sorting in lambda

data = [(1,3),(4,1),(2,2)]
sorteddata = sorted(data, key=lambda x:x[0])
print(sorteddata)


marks ={"A":75, "B":90,"C":60}
sorted_marks = dict(sorted(marks.items(), key=lambda x:x[1]))
print(sorted_marks)

