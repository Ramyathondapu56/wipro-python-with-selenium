#function is a block of code that performs specific task
#def functionname()

#default function with no parameters
def printdata():
    print("Hello world")

#call the function
printdata()

#function with parameters
def printdata(Name):
    print("Hello",Name)
#pass the argument
printdata("Rena")
printdata("Tina")

#return statement
#to return the function value return statment is used

def sq(num):
    result = num *num
    return result

#function call
square = sq(3)
print("square =",square)

#pass statement_ it will preserve ur code, it is like phasholder
#function pass
def func_pass():
    pass
#call the function
func_pass()

#mutiple return values
def cal(a,b):
    return a-b,a+b,a*b

add,sub,mul=cal(10,7)
print(add)
print(sub)
print(mul)
# function calling a another function

def areaofrect(len,width):
    return len*width

def areaofsq(side):
    return side*side

value = areaofrect(4,6)
sq = areaofsq(value)
print(sq)

# function with a loop
def even(limit):
    if limit % 2 ==0:
        return "even"
    else:
        return "odd"

print(even(10))
print(even(11))











