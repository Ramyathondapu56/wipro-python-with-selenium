# dictionary items - key values
#similar to list and tuples
# for integers, tuples, and strings- keys must be immutable
#list cannot be used in the key for the dict as it is mutable in nature

country = {

    "India":"Delhi",
    "Canada":"Ottawa",
    "England":"London"
}
print(country)


#add elements

country["Italy"] = "Rome"
print(country)

#remove elements
del country["India"]
print(country)

# clear
# country.clear()
# print(country)

#iterate among the dict
for coun in country:
    print(coun)

#length of the dict
print(len(country))

# for integers keys must be immutable
# integer as a key
my_dict = {1:"one", 2: "two", 3:"three"}
print(my_dict)

my_dict = {1:"four", 2: "two", 3:"three",1:"one"}
print(my_dict)

# for integers keys must be immutable

#tuples as a key
my_dict = {(1,2):"one two" , 3:"three"}

my_dict = {(1,2):"one two" , 3:"three",3:"four"}
print(my_dict)
"""
#list as key
my_dict = {1: "Hello", [1, 2]: "There you"}
print(my_dict)"""

# pop - removes the item with spec key

fruits = {'apple': 5, 'banana': 10, 'cherry': 15}

value = fruits.pop('banana')

print("Popped value:",value)
print("Dictionary after pop:", fruits)

#pop

country.pop("Canada")
print(country)

#update - adds or changes the dict
country.update()
print(country)

#keys()

#value

#popitem() return the last inserted keyword
country.popitem()
print(country)

# copy returns the copy of dict
country.copy()
print(country)

# dict inside the list
employees =employees = [

    {"id": 1, "name": "Harsha", "role": "QA"},
     {"id": 2, "name": "Anil", "role": "Dev"},
     {"id": 3, "name": "Ravi", "role": "Manager"}
]

print(employees[0])
print(employees[0]["name"])

for emp in employees:
    print(emp["name"], emp ["role"])

employees.append({"id": 4, "name": "Sita", "role": "Tester"})
print(employees)
employees.pop(8)
print(employees)


# search a item in the list
for emp in employees:
    if emp["name"]== "Harsha":
        print(emp)