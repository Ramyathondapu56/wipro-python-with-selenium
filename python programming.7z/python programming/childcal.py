import calculator
print(calculator.add(12,8))
print(calculator.sub(12,8))