#skip - if defects are there
# skip-if the testcases are absolute
#windows. mobile-os dependency
#browsers -FF,IE, chrdef
import pytest
#testcase 1
def testcase1():
    print("Testcase1 is executed")
#testcase2
@pytest.mark.skip
def testcase2():
    print("Testcase2 is executed")
#testcase3
def testcase3():
    print("Testcase3 is executed")
#testcase4
@pytest.mark.skip
def openbrowser():
    print("Opening the browser")