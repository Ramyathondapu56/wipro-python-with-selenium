import pytest

@pytest.fixture(scope="class")
def openbrowser():
    print("\n[SETUP] Open browser - CLASS LEVEL")

@pytest.fixture(scope="class")
def closebrowser():
    print("\n[TEARDOWN] Close browser - CLASS LEVEL")

import pytest

@pytest.fixture(scope="module")
def openbrowser():
    print("\n[SETUP] Open browser - MODULE LEVEL")

@pytest.fixture(scope="module")
def closebrowser():
    print("\n[TEARDOWN] Close browser - MODULE LEVEL")


import pytest

@pytest.fixture(scope="session")
def openbrowser():
    print("\n[SETUP] Open browser - SESSION LEVEL")

@pytest.fixture(scope="session")
def closebrowser():
    print("\n[TEARDOWN] Close browser - SESSION LEVEL")