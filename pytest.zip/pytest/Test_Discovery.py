#unit testing is type of testing done by the developers
#what component they have developed they do the testing for it before integrating it to the other module

#get defects earlier
#pytest in python, junit and unit-java
#pytest is used by developers and testers

#test discovery-rules used create the pytest tests

#files should start with test_
#functions should start with test
def testcase1():
    print("Testcase1 is execetes")

def testcase2():
    print("Testcase2 is execetes")

def testcase3():
    print("Testcase3 is execetes")

def openbrowser():
    print("opening the browser")