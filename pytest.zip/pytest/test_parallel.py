import pytest

def testcase1():
    print("Testcase1 is execetes")

def testcase2():
    print("Testcase2 is execetes")

def testcase3():
    print("Testcase3 is execetes")

def testcase4():
    print("Testcase4 is execetes")

def testcase5():
    print("Testcase5 is execetes")
def test_login():
    print("Login test is executed")


