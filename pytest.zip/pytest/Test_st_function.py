#function level setup and teardown
#these run before and after each test function
#setup at function level
def setup_function(function):
    print("opening the browser")

#teardown up at the function
def teardown_function(function):
    print("closing the browser")
#testcase 2
def testcase1():
    print("Testcase1 is executed")
#testcase2
def testcase2():
    print("Testcase2 is executed")
#testcase3
def testcase3():
    print("Testcase3 is executed")
#testcase4
def openbrowser():
    print("Opening the browser")