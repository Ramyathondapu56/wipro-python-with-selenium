# used inside the class
# runs before and after the test methods  inside the class


class Testclass1:

    def setup_class(cls):
        print("API Authorization needed with username and pasword")

    def teardown_class(cls):
        print("API Authorization closed")

    def setup_method(module):
        print("opening the browser")

    def teardown_method(function):
        print("closing the browser")

    def testcase1(self):
        print("Testcase 1 is executed")

    def testcase2(self):
        print("Testcase 2 is executed")

    def test_case3(self):
        print("Testcase 3 is executed")


class Testclass2:

    def setup_class(cls):
        print("API Authorization needed with username and pasword")

    def teardown_class(cls):
        print("API Authorization closed")

    def testcase1(self):
        print("Testcase 1 is executed")

    def testcase2(self):
        print("Testcase 2 is executed")

    def test_case3(self):
        print("Testcase 3 is executed")