import requests
from jsonschema import validate

def test_user_schema():
    response = requests.get("https://jsonplaceholder.typicode.com/users/1")
    data = response.json()

    schema = {
        "type": "object",
        "properties": {
            "id": {"type": "number"},
            "name": {"type": "string"},
            "username": {"type": "string"},
            "email": {"type": "string"}
        },
        "required": ["id", "name", "username", "email"]
    }

    validate(instance=data, schema=schema)