def test_fixture_chain(base_url, auth_token, test_user):
    assert base_url.startswith("https")
    assert auth_token is not None
    assert test_user["username"] == "qa_user"