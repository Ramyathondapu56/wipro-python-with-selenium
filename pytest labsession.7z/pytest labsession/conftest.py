import pytest
import requests

BASE_URL = "https://jsonplaceholder.typicode.com"


# ---------------- SESSION TOKEN ----------------
@pytest.fixture(scope="session")
def auth_token():
    """
    Mock login because public APIs block automation login
    """
    token = "dummy_token_12345"
    print("\nToken generated once per session:", token)
    return token


# ---------------- BASE URL ----------------
@pytest.fixture(scope="session")
def base_url():
    return BASE_URL


# ---------------- CREATE USER (SETUP + TEARDOWN USING YIELD) ----------------
@pytest.fixture
def test_user(base_url):
    """
    Create user before test and delete after test
    """

    payload = {
        "name": "Ramya",
        "username": "qa_user",
        "email": "qa@test.com"
    }

    # Setup
    response = requests.post(f"{base_url}/users", json=payload)
    assert response.status_code == 201
    user_data = response.json()

    print("\nUser created:", user_data)

    yield user_data

    # Teardown (Fake delete — placeholder API doesn't actually delete)
    print("User cleanup done")