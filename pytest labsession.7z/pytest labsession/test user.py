def test_user_created(test_user):
    assert test_user["name"] == "Ramya"
    assert test_user["email"] == "qa@test.com"