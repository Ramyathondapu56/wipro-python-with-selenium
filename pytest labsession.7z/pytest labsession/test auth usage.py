def test_token_exists(auth_token):
    assert auth_token is not None


def test_token_length(auth_token):
    assert len(auth_token) > 5