import pytest
import requests

@pytest.mark.parametrize("endpoint,expected", [
    ("/users", 200),
    ("/users/1", 200),
    ("/users/9999", 404)
])
def test_status_codes(endpoint, expected):
    url = "https://jsonplaceholder.typicode.com" + endpoint
    response = requests.get(url)
    assert response.status_code == expected