# variables = uesd to store the data
# instance variables - global variables at class level
# ocal variables - inside the method only

#instance variables example

class Student:
    # class  variable
    school ="Sri vidhya"
    def __init__(self, name, marks):
        self.name = name # instance variables or global variables
        self.marks = marks # instance variables or global variables

    def show(self):
        Schoolcity = "Bangalore" # local variable = scope is inside the method
        print(self.marks, self.marks)
        print(Schoolcity)
        print(self.school)


s1 = Student("HARSHA",85)
s2 = Student("Amit",90)

s1.show()
s2.show()


class Employee:
    company = "Wipro"

e1 = Employee()
e2 = Employee()

print(e1.company)
print(e2.company)

