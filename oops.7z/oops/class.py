# class is a blue print or a template
# which describes the state/ behaviour of its object



class Student:

    # data or the properties
    studentname = "Ramya"
    studentID = 21216

    # self is used to access the attributes of the class we have defined and it is automatically loaded
    # self represents the instance of the class


# create  a function to access the data
    def displaystudentdetails(self):
         print(self.studentname)
         print(self.studentID)
# create the object of the class
a = Student()
a.displaystudentdetails()
#2 question
class Employee:
    def __init__(self, emp_id, emp_name, emp_dept):
        self.emp_id = emp_id
        self.emp_name = emp_name
        self.emp_dept = emp_dept
    def display(self):
        print(self.emp_id)
        print(self.emp_name)
        print(self.emp_dept)
        print("-" * 30)
# Creating two employee objects with employee details
emp1 = Employee(101, "Ramya", "HR")
emp2 = Employee(102, "Arun", "IT")

# Display their data
emp1.display()
emp2.display()