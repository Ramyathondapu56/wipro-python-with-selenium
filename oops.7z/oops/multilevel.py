# Parent class
class Employee:
    def __init__(self, name, empid):
        self.name = name
        self.empid = empid

    def empdetails(self):
        print("Employee Name:", self.name, "| Employee ID:", self.empid)


# Child class (Level 1)
class Manager(Employee):
    def approve_leave(self):
        print("Leave approved by Manager")


# Grandchild class (Level 2)
class SeniorManager(Manager):
    def conduct_meeting(self):
        print("Meeting conducted by Senior Manager")


# Example usage
sm = SeniorManager("John", 7878)
sm.empdetails()       # Inherited from Employee
sm.approve_leave()    # Inherited from Manager
sm.conduct_meeting()  # Defined in SeniorManager