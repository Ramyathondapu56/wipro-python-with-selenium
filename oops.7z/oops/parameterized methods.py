# default methods - builtin method, user defined methods - method name, method body

# parametrized methods-
# it allows the same method to behave differently for diff inputs


class Calculator:
    def add(selfself, a, b):
        print(a + b)

c = Calculator()
c.add(10,20)
c.add(5,7)

#Default parameters

class Test:
    def run(self , browser = "chrome"):
        print("Running on ", browser)
t = Test()
t.run()
t.run("Firefox")


# * rags parameters methods

class Numbers:
    def total(self , *args):
        print(sum(args))

n = Numbers()
n.total(10,20,30)
n.total(10)
n.total(10,60)

