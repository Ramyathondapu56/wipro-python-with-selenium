class A:
    def show(self):
        print("Class A")

class B(A):
    pass
    #def show(self):
    #print("Class B")

class C(A):
    pass
    #def
    print("Class C")


class D(B ,C):
    print("class D")


d = D()
d.show()
print(D.mro())



#7 question
class Calculator:
    def divide(self, a, b):
        print (a / b)

class SafeCalculator(Calculator):
    def divide(self, a, b):
        try:
            print (a / b)
        except ZeroDivisionError:
            print ("Error")

# Demonstration
calc = Calculator()
safe_calc = SafeCalculator()

print("Normal:", calc.divide(10, 2))
print("Safe:", safe_calc.divide(10, 0))

#8 question
class Payment:
    def pay(self, amount):
        raise NotImplementedError("Subclass must implement pay()")

class CreditCard(Payment):
    def pay(self, amount):
        return {amount}

class UPI(Payment):
    def pay(self, amount):
        return {amount}

class NetBanking(Payment):
    def pay(self, amount):
        return {amount}

def process_payment(payment_obj, amount):
    print(payment_obj.pay(amount))

# Demonstration
process_payment(CreditCard(), 1000)
process_payment(UPI(), 500)
process_payment(NetBanking(), 2000)


#8th question 2nd model
class payment:
    def pay(self):
        print("doing payment")
class Creditcard(payment):
    def pay(self):
        print("paying using Creditcard")
class UPI(Creditcard):
    def pay(self):
        print("paying using upi")
class Netbanking(UPI):
    def pay(self):
        print("paying using netbanking")

a=payment()
b=Creditcard()
c=UPI()
d=Netbanking()
a.pay()
b.pay()
c.pay()
d.pay()